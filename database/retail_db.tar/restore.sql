--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE final_schema;
--
-- Name: final_schema; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE final_schema WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE final_schema OWNER TO postgres;

\unrestrict (null)
\connect final_schema
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: add_payment(integer, numeric, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_payment(IN p_order_id integer, IN p_amount numeric, IN p_payment_method character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_total NUMERIC(10,2);
    v_paid NUMERIC(10,2);
    v_remaining NUMERIC(10,2);
    v_txn_id VARCHAR(15);
    v_exists INT;
BEGIN

-- Check order exists
SELECT total_amount INTO v_total
FROM orders
WHERE order_id = p_order_id;

IF v_total IS NULL THEN
    RAISE EXCEPTION
    'Order % does not exist', p_order_id;
END IF;

-- Validate payment amount
IF p_amount <= 0 THEN
    RAISE EXCEPTION
    'Payment amount must be greater than zero';
END IF;

-- Calculate amount already paid
SELECT COALESCE(SUM(amount),0)
INTO v_paid
FROM payments
WHERE order_id = p_order_id;

-- Prevent overpayment
IF v_paid + p_amount > v_total THEN
    RAISE EXCEPTION
    'Payment exceeds remaining amount. Remaining: %',
    v_total - v_paid;
END IF;

-- Generate unique transaction ID
LOOP
    v_txn_id := 'TXN' || LPAD(FLOOR(random()*1000000000)::TEXT,9,'0');

    SELECT COUNT(*)
    INTO v_exists
    FROM payments
    WHERE transaction_id = v_txn_id;

    EXIT WHEN v_exists = 0;
END LOOP;

-- Insert payment
INSERT INTO payments(order_id, amount, payment_method, transaction_id)
VALUES (p_order_id, p_amount, p_payment_method, v_txn_id);

-- Calculate remaining amount
v_remaining := v_total - (v_paid + p_amount);

-- Update order status
IF v_remaining = 0 THEN
    UPDATE orders
    SET status = 'Delivered'
    WHERE order_id = p_order_id;
ELSE
    UPDATE orders
    SET status = 'Confirmed'
    WHERE order_id = p_order_id;
END IF;

RAISE NOTICE
'Payment of % added for Order %. Transaction: %. Remaining: %',
p_amount, p_order_id, v_txn_id, v_remaining;

END;
$$;


ALTER PROCEDURE public.add_payment(IN p_order_id integer, IN p_amount numeric, IN p_payment_method character varying) OWNER TO postgres;

--
-- Name: browse_products(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.browse_products(p_branch_id integer, p_category_id integer, p_brand_id integer DEFAULT NULL::integer) RETURNS TABLE(product_id integer, product_name character varying, brand character varying, price numeric, quantity integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        p.product_id,
        p.name,
        b.brand_name,
        p.price,
        a.quantity
    FROM products p
    JOIN brands b ON p.brand_id = b.brand_id
    JOIN accomodates a ON p.product_id = a.product_id
    WHERE
        a.branch_id = p_branch_id
        AND p.category_id = p_category_id
        AND (p.brand_id = p_brand_id OR p_brand_id IS NULL)
    ORDER BY p.price ;
END;
$$;


ALTER FUNCTION public.browse_products(p_branch_id integer, p_category_id integer, p_brand_id integer) OWNER TO postgres;

--
-- Name: cheapest_products_branch_category(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cheapest_products_branch_category(p_branch integer, p_category integer, limit_count integer DEFAULT 50) RETURNS TABLE(product_name character varying, brand character varying, price numeric, quantity integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM branches
        WHERE branch_id = p_branch
    ) THEN
        RAISE EXCEPTION 'Branch % does not exist', p_branch;
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM categories
        WHERE category_id = p_category
    ) THEN
        RAISE EXCEPTION 'Category % does not exist', p_category;
    END IF;
    IF limit_count IS NULL OR limit_count <= 0 THEN
        RAISE EXCEPTION 'Limit count must be greater than 0';
    END IF;
    IF NOT EXISTS (
        SELECT 1
        FROM products p
        JOIN accomodates a ON p.product_id = a.product_id
        WHERE a.branch_id = p_branch
        AND p.category_id = p_category
        AND COALESCE(a.quantity,0) > 0
    ) THEN
        RAISE EXCEPTION
        'No products available in branch % for category %',
        p_branch, p_category;
    END IF;
    RETURN QUERY
    SELECT
        p.name,
		b.brand_name,
        p.price,
        COALESCE(a.quantity,0)
    FROM products p
    JOIN accomodates a
        ON p.product_id = a.product_id
	JOIN brands b 
        ON p.brand_id = b.brand_id
    WHERE
        a.branch_id = p_branch
        AND p.category_id = p_category
        AND COALESCE(a.quantity,0) > 0
    ORDER BY p.price ASC
    LIMIT limit_count;
END;
$$;


ALTER FUNCTION public.cheapest_products_branch_category(p_branch integer, p_category integer, limit_count integer) OWNER TO postgres;

--
-- Name: create_purchase_order(integer, integer, integer[], integer[], numeric[]); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.create_purchase_order(IN p_supplier_id integer, IN p_branch_id integer, IN p_product_ids integer[], IN p_quantities integer[], IN p_cost_prices numeric[] DEFAULT NULL::numeric[])
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_po_id INT;
    v_exists INT;
    v_cost NUMERIC(10,2);
    i INT;
BEGIN
-- Validate arrays
IF array_length(p_product_ids,1) <> array_length(p_quantities,1) THEN
    RAISE EXCEPTION
    'Products and quantities count must match';
END IF;
-- Check supplier exists
SELECT COUNT(*)
INTO v_exists
FROM suppliers
WHERE supplier_id = p_supplier_id;
IF v_exists = 0 THEN
    RAISE EXCEPTION
    'Supplier % does not exist', p_supplier_id;
END IF;
-- Check branch exists
SELECT COUNT(*)
INTO v_exists
FROM branches
WHERE branch_id = p_branch_id;
IF v_exists = 0 THEN
    RAISE EXCEPTION
    'Branch % does not exist', p_branch_id;
END IF;
-- Create purchase order
INSERT INTO purchase_orders(
    supplier_id,
    branch_id,
    expected_date,
    status)
VALUES (
    p_supplier_id,
    p_branch_id,
    CURRENT_TIMESTAMP + INTERVAL '5 days',
    'Pending')
RETURNING po_id INTO v_po_id;
-- Insert purchase items
FOR i IN 1..array_length(p_product_ids,1)
LOOP
    -- Check product exists
    SELECT COUNT(*)
    INTO v_exists
    FROM products
    WHERE product_id = p_product_ids[i];
    IF v_exists = 0 THEN
        RAISE EXCEPTION
        'Product % does not exist', p_product_ids[i];
    END IF;
    -- Check supplier supplies the product
    SELECT COUNT(*)
    INTO v_exists
    FROM supplies
    WHERE supplier_id = p_supplier_id
    AND product_id = p_product_ids[i];
    IF v_exists = 0 THEN
        RAISE EXCEPTION
        'Supplier % does not supply product %',
        p_supplier_id, p_product_ids[i];
    END IF;
    -- Validate quantity
    IF p_quantities[i] <= 0 THEN
        RAISE EXCEPTION
        'Invalid quantity for product %',
        p_product_ids[i];
    END IF;
    -- Determine cost price
    IF p_cost_prices IS NULL THEN
        SELECT cost_price
        INTO v_cost
        FROM products
        WHERE product_id = p_product_ids[i];
    ELSE
        v_cost := p_cost_prices[i];
    END IF;
    -- Insert purchase item
    INSERT INTO purchase_items(
        po_id,
        product_id,
        quantity,
        cost_price
    )
    VALUES (
        v_po_id,
        p_product_ids[i],
        p_quantities[i],
        v_cost
    );
END LOOP;
RAISE NOTICE
'Purchase order % created successfully',
v_po_id;
END;
$$;


ALTER PROCEDURE public.create_purchase_order(IN p_supplier_id integer, IN p_branch_id integer, IN p_product_ids integer[], IN p_quantities integer[], IN p_cost_prices numeric[]) OWNER TO postgres;

--
-- Name: place_order(integer, integer, integer, integer[], integer[], numeric[]); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.place_order(IN p_user_id integer, IN p_customer_id integer, IN p_branch_id integer, IN p_product_ids integer[], IN p_quantities integer[], IN p_discounts numeric[])
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_user_branch INT;
    v_branch_id INT;
    v_order_id INT;
    v_price NUMERIC(10,2);
    v_total NUMERIC(10,2);
    v_stock INT;
    v_invoice VARCHAR(30);
    i INT;
BEGIN

IF array_length(p_product_ids,1) <> array_length(p_quantities,1)
   OR array_length(p_product_ids,1) <> array_length(p_discounts,1)
THEN
    RAISE EXCEPTION
    'Products, quantities and discounts count must match';
END IF;

SELECT branch_id INTO v_user_branch
FROM users
WHERE user_id = p_user_id;

IF v_user_branch IS NULL THEN
    v_branch_id := p_branch_id;
ELSE
    v_branch_id := v_user_branch;
END IF;

IF v_branch_id IS NULL THEN
    RAISE EXCEPTION 'Branch must be specified for admin users';
END IF;

FOR i IN 1..array_length(p_product_ids,1)
LOOP
    IF p_quantities[i] <= 0 THEN
        RAISE EXCEPTION
        'Invalid quantity for product %', p_product_ids[i];
    END IF;

    SELECT quantity INTO v_stock
    FROM accomodates
    WHERE branch_id = v_branch_id
    AND product_id = p_product_ids[i];

    IF v_stock IS NULL THEN
        RAISE EXCEPTION
        'Product % not available in branch %',
        p_product_ids[i], v_branch_id;
    END IF;

    IF v_stock < p_quantities[i] THEN
        RAISE EXCEPTION
        'Insufficient stock for product %',
        p_product_ids[i];
    END IF;
END LOOP;

INSERT INTO orders(customer_id, branch_id, status, total_amount)
VALUES (p_customer_id, v_branch_id, 'Pending', 0)
RETURNING order_id INTO v_order_id;

v_invoice := 'INV' || LPAD(v_order_id::TEXT,6,'0');

UPDATE orders
SET invoice_number = v_invoice
WHERE order_id = v_order_id;

FOR i IN 1..array_length(p_product_ids,1)
LOOP

    SELECT price INTO v_price
    FROM products
    WHERE product_id = p_product_ids[i];

    INSERT INTO order_items(order_id, product_id, quantity, price, discount)
    VALUES (
        v_order_id,
        p_product_ids[i],
        p_quantities[i],
        v_price,
        p_discounts[i]
    );

    UPDATE accomodates
    SET quantity = quantity - p_quantities[i]
    WHERE branch_id = v_branch_id
    AND product_id = p_product_ids[i];

END LOOP;

SELECT SUM(sub_total)
INTO v_total
FROM order_items
WHERE order_id = v_order_id;

UPDATE orders
SET total_amount = v_total
WHERE order_id = v_order_id;

RAISE NOTICE
'Order created successfully. Order ID: %, Invoice: %',
v_order_id, v_invoice;

END;
$$;


ALTER PROCEDURE public.place_order(IN p_user_id integer, IN p_customer_id integer, IN p_branch_id integer, IN p_product_ids integer[], IN p_quantities integer[], IN p_discounts numeric[]) OWNER TO postgres;

--
-- Name: process_return(integer, integer, character varying, integer[], integer[], character varying[], numeric[]); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.process_return(IN p_user_id integer, IN p_order_id integer, IN p_reason character varying, IN p_product_ids integer[], IN p_quantities integer[], IN p_conditions character varying[], IN p_refund_amounts numeric[] DEFAULT NULL::numeric[])
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_return_id INT;
    v_branch INT;
    v_user_branch INT;
    v_order_qty INT;
    v_sub_total NUMERIC(10,2);
    v_unit_value NUMERIC(10,2);
    v_refund NUMERIC(10,2);
    i INT;
BEGIN

-- Validate arrays
IF array_length(p_product_ids,1) <> array_length(p_quantities,1)
OR array_length(p_product_ids,1) <> array_length(p_conditions,1)
THEN
    RAISE EXCEPTION
    'Product, quantity and condition arrays must match';
END IF;

-- Get order branch
SELECT branch_id
INTO v_branch
FROM orders
WHERE order_id = p_order_id;

IF v_branch IS NULL THEN
    RAISE EXCEPTION
    'Order % does not exist', p_order_id;
END IF;

-- USER VALIDATION
IF p_user_id IS NOT NULL THEN

    SELECT branch_id
    INTO v_user_branch
    FROM users
    WHERE user_id = p_user_id;

    IF v_user_branch IS NULL THEN
        RAISE EXCEPTION
        'Invalid user %', p_user_id;
    END IF;

    IF v_user_branch != v_branch THEN
        RAISE EXCEPTION
        'User cannot process returns for another branch';
    END IF;

END IF;

-- Prevent duplicate return
IF EXISTS (
    SELECT 1
    FROM return_orders
    WHERE order_id = p_order_id
) THEN
    RAISE EXCEPTION
    'Order % has already been returned', p_order_id;
END IF;

-- Create return order
INSERT INTO return_orders(order_id, reason)
VALUES (p_order_id, p_reason)
RETURNING return_id INTO v_return_id;

-- Process items
FOR i IN 1..array_length(p_product_ids,1)
LOOP

    -- Get original order item details
    SELECT quantity, sub_total
    INTO v_order_qty, v_sub_total
    FROM order_items
    WHERE order_id = p_order_id
    AND product_id = p_product_ids[i]
    LIMIT 1;

    IF v_order_qty IS NULL THEN
        RAISE EXCEPTION
        'Product % was not part of order %',
        p_product_ids[i], p_order_id;
    END IF;

    -- Validate return quantity
    IF p_quantities[i] <= 0 OR p_quantities[i] > v_order_qty THEN
        RAISE EXCEPTION
        'Invalid return quantity for product %',
        p_product_ids[i];
    END IF;

    -- Refund calculation
    IF p_refund_amounts IS NULL THEN

        v_unit_value := ROUND(v_sub_total / v_order_qty,2);

        IF p_conditions[i] = 'Unused' THEN
            v_refund := ROUND(v_unit_value * p_quantities[i],2);

        ELSIF p_conditions[i] = 'Opened' THEN
            v_refund := ROUND(v_unit_value * p_quantities[i] * 0.70,2);

        ELSIF p_conditions[i] = 'Damaged' THEN
            v_refund := ROUND(v_unit_value * p_quantities[i] * 0.30,2);

        ELSE
            RAISE EXCEPTION
            'Invalid condition %', p_conditions[i];
        END IF;

    ELSE
        v_refund := p_refund_amounts[i];
    END IF;

    -- Insert return item
    INSERT INTO return_items(
        return_id,
        product_id,
        quantity,
        item_condition,
        refund_amount
    )
    VALUES(
        v_return_id,
        p_product_ids[i],
        p_quantities[i],
        p_conditions[i],
        v_refund
    );

    -- Update inventory
    UPDATE accomodates
    SET quantity = quantity + p_quantities[i]
    WHERE branch_id = v_branch
    AND product_id = p_product_ids[i];

    IF NOT FOUND THEN
        INSERT INTO accomodates(branch_id, product_id, quantity)
        VALUES(v_branch, p_product_ids[i], p_quantities[i]);
    END IF;

END LOOP;

RAISE NOTICE
'Return processed successfully. Return ID: %',
v_return_id;

END;
$$;


ALTER PROCEDURE public.process_return(IN p_user_id integer, IN p_order_id integer, IN p_reason character varying, IN p_product_ids integer[], IN p_quantities integer[], IN p_conditions character varying[], IN p_refund_amounts numeric[]) OWNER TO postgres;

--
-- Name: products_in_price_range(integer, integer, numeric, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.products_in_price_range(p_branch integer, p_category integer, min_price numeric, max_price numeric) RETURNS TABLE(product_name character varying, brand character varying, price numeric, quantity integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM branches
        WHERE branch_id = p_branch
    ) THEN
        RAISE EXCEPTION 'Branch % does not exist', p_branch;
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM categories
        WHERE category_id = p_category
    ) THEN
        RAISE EXCEPTION 'Category % does not exist', p_category;
    END IF;
    IF min_price IS NULL OR max_price IS NULL THEN
        RAISE EXCEPTION 'Price values cannot be NULL';
    END IF;
    IF min_price < 0 OR max_price < 0 THEN
        RAISE EXCEPTION 'Price cannot be negative';
    END IF;
    IF min_price > max_price THEN
        RAISE EXCEPTION 'Minimum price cannot be greater than maximum price';
    END IF;
    RETURN QUERY
    SELECT
        p.name,
        b.brand_name,
        p.price,
        COALESCE(a.quantity,0)
    FROM products p
    JOIN brands b
        ON p.brand_id = b.brand_id
    JOIN accomodates a
        ON p.product_id = a.product_id
    WHERE
        a.branch_id = p_branch
        AND p.category_id = p_category
        AND p.price BETWEEN min_price AND max_price
        AND COALESCE(a.quantity,0) > 0
    ORDER BY p.price;
END;
$$;


ALTER FUNCTION public.products_in_price_range(p_branch integer, p_category integer, min_price numeric, max_price numeric) OWNER TO postgres;

--
-- Name: receive_goods(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.receive_goods(IN p_po_id integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    rec RECORD;
    v_branch INT;
    v_status VARCHAR;
BEGIN

-- Check purchase order exists
SELECT branch_id, status
INTO v_branch, v_status
FROM purchase_orders
WHERE po_id = p_po_id;

IF v_branch IS NULL THEN
    RAISE EXCEPTION
    'Purchase order % does not exist', p_po_id;
END IF;

-- Prevent receiving twice
IF v_status = 'Delivered' THEN
    RAISE EXCEPTION
    'Goods already received for purchase order %', p_po_id;
END IF;

-- Update inventory
FOR rec IN
    SELECT product_id, quantity
    FROM purchase_items
    WHERE po_id = p_po_id
LOOP

    UPDATE accomodates
    SET quantity = quantity + rec.quantity
    WHERE branch_id = v_branch
    AND product_id = rec.product_id;

    -- Insert if product not stored in branch yet
    IF NOT FOUND THEN
        INSERT INTO accomodates(
            branch_id,
            product_id,
            quantity
        )
        VALUES (
            v_branch,
            rec.product_id,
            rec.quantity
        );
    END IF;

END LOOP;

-- Update status
UPDATE purchase_orders
SET status = 'Delivered'
WHERE po_id = p_po_id;

RAISE NOTICE
'Goods received for purchase order %',
p_po_id;

END;
$$;


ALTER PROCEDURE public.receive_goods(IN p_po_id integer) OWNER TO postgres;

--
-- Name: request_stock_movement(integer[], integer, integer, integer[], character varying[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.request_stock_movement(p_product_ids integer[], p_from_branch integer, p_to_branch integer, p_quantities integer[], p_reasons character varying[]) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    i INT;
    available_qty INT;
BEGIN

    IF array_length(p_product_ids, 1) IS DISTINCT FROM array_length(p_quantities, 1) THEN
        RAISE EXCEPTION 'Product IDs and Quantities must have same length';
    END IF;
    IF array_length(p_product_ids, 1) IS DISTINCT FROM array_length(p_reasons, 1) THEN
        RAISE EXCEPTION 'Product IDs and Reasons must have same length';
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM branches WHERE branch_id = p_from_branch
    ) THEN
        RAISE EXCEPTION 'Source branch % does not exist', p_from_branch;
    END IF;
    IF NOT EXISTS (
        SELECT 1 FROM branches WHERE branch_id = p_to_branch
    ) THEN
        RAISE EXCEPTION 'Destination branch % does not exist', p_to_branch;
    END IF;
    IF p_from_branch = p_to_branch THEN
        RAISE EXCEPTION 'Source and destination branch cannot be the same';
    END IF;
    FOR i IN 1..array_length(p_product_ids, 1) LOOP
        IF NOT EXISTS (
            SELECT 1 FROM products
            WHERE product_id = p_product_ids[i]
        ) THEN
            RAISE EXCEPTION 'Product % does not exist', p_product_ids[i];
        END IF;
        IF p_quantities[i] IS NULL OR p_quantities[i] <= 0 THEN
            RAISE EXCEPTION 'Quantity must be greater than 0 for product %', p_product_ids[i];
        END IF;
        IF p_reasons[i] IS NULL OR TRIM(p_reasons[i]) = '' THEN
            RAISE EXCEPTION 'Reason cannot be empty for product %', p_product_ids[i];
        END IF;
        SELECT quantity
        INTO available_qty
        FROM accomodates
        WHERE branch_id = p_from_branch
        AND product_id = p_product_ids[i];
        IF available_qty IS NULL THEN
            RAISE EXCEPTION 'Product % not available in source branch %',
                p_product_ids[i], p_from_branch;
        END IF;
        IF available_qty < p_quantities[i] THEN
            RAISE EXCEPTION
                'Insufficient stock for product %. Available: %, Requested: %',
                p_product_ids[i], available_qty, p_quantities[i];
        END IF;
        INSERT INTO stock_movements (
            product_id,
            from_branch_id,
            to_branch_id,
            quantity,
            reason
        )
        VALUES (
            p_product_ids[i],
            p_from_branch,
            p_to_branch,
            p_quantities[i],
            p_reasons[i]
        );
        UPDATE accomodates
        SET quantity = quantity - p_quantities[i]
        WHERE branch_id = p_from_branch
        AND product_id = p_product_ids[i];
        IF EXISTS (
            SELECT 1 FROM accomodates
            WHERE branch_id = p_to_branch
            AND product_id = p_product_ids[i]
        ) THEN
            UPDATE accomodates
            SET quantity = quantity + p_quantities[i]
            WHERE branch_id = p_to_branch
            AND product_id = p_product_ids[i];
        ELSE
            INSERT INTO accomodates (branch_id, product_id, quantity)
            VALUES (p_to_branch, p_product_ids[i], p_quantities[i]);
        END IF;
    END LOOP;
END;
$$;


ALTER FUNCTION public.request_stock_movement(p_product_ids integer[], p_from_branch integer, p_to_branch integer, p_quantities integer[], p_reasons character varying[]) OWNER TO postgres;

--
-- Name: search_products_in_branch(integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.search_products_in_branch(p_branch_id integer, keyword character varying) RETURNS TABLE(product_id integer, product_name character varying, brand character varying, price numeric, quantity integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM branches
        WHERE branch_id = p_branch_id
    ) THEN
        RAISE EXCEPTION 'Branch with id % does not exist', p_branch_id;
    END IF;
    IF keyword IS NULL OR TRIM(keyword) = '' THEN
        RAISE EXCEPTION 'Search keyword cannot be NULL or empty';
    END IF;
    RETURN QUERY
    SELECT 
        p.product_id,
        p.name,
        b.brand_name,
        p.price,
        COALESCE(a.quantity,0)
    FROM products p
    JOIN brands b 
        ON p.brand_id = b.brand_id
    JOIN accomodates a 
        ON p.product_id = a.product_id
    WHERE 
        a.branch_id = p_branch_id
        AND p.name ILIKE '%' || TRIM(keyword) || '%'
        AND COALESCE(a.quantity,0) > 0
    ORDER BY p.price DESC;
END;
$$;


ALTER FUNCTION public.search_products_in_branch(p_branch_id integer, keyword character varying) OWNER TO postgres;

--
-- Name: update_product_price(integer, numeric); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_product_price(p_product_id integer, new_price numeric) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_price NUMERIC;
BEGIN
    SELECT price INTO current_price
    FROM products
    WHERE product_id = p_product_id;
    IF current_price IS NULL THEN
        RAISE EXCEPTION 'Product with ID % does not exist', p_product_id;
    END IF;
    IF new_price IS NULL THEN
        RAISE EXCEPTION 'New price cannot be NULL';
    END IF;
    IF new_price <= 0 THEN
        RAISE EXCEPTION 'Price must be greater than 0';
    END IF;
    IF current_price = new_price THEN
        RAISE NOTICE 'Price is already % for product %', new_price, p_product_id;
        RETURN;
    END IF;
    UPDATE products
    SET price = new_price
    WHERE product_id = p_product_id;
END;
$$;


ALTER FUNCTION public.update_product_price(p_product_id integer, new_price numeric) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accomodates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accomodates (
    branch_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    CONSTRAINT accomodates_quantity_check CHECK ((quantity >= 0))
);


ALTER TABLE public.accomodates OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    category_id integer NOT NULL,
    category_name character varying(50) NOT NULL,
    description character varying(100)
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    order_item_id integer NOT NULL,
    order_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    price numeric(10,2) NOT NULL,
    discount numeric(5,2) DEFAULT 0,
    sub_total numeric(10,2) GENERATED ALWAYS AS (((((quantity)::numeric * price) * ((100)::numeric - discount)) * 0.01)),
    CONSTRAINT order_items_discount_check CHECK ((discount >= (0)::numeric)),
    CONSTRAINT order_items_price_check CHECK ((price > (0)::numeric)),
    CONSTRAINT order_items_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    product_id integer NOT NULL,
    name character varying(150) NOT NULL,
    category_id integer NOT NULL,
    brand_id integer NOT NULL,
    unit_id integer NOT NULL,
    price numeric(10,2) NOT NULL,
    gst numeric(5,2),
    cost_price numeric(10,2) NOT NULL,
    description character varying(500),
    CONSTRAINT products_cost_price_check CHECK ((cost_price > (0)::numeric)),
    CONSTRAINT products_gst_check CHECK ((gst >= (0)::numeric)),
    CONSTRAINT products_price_check CHECK ((price > (0)::numeric))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: best_selling_products; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.best_selling_products AS
 SELECT p.product_id,
    p.name AS product_name,
    c.category_name,
    sum(oi.quantity) AS total_sold
   FROM ((public.order_items oi
     JOIN public.products p ON ((oi.product_id = p.product_id)))
     JOIN public.categories c ON ((p.category_id = c.category_id)))
  GROUP BY p.product_id, p.name, c.category_name
  ORDER BY (sum(oi.quantity)) DESC
 LIMIT 10;


ALTER VIEW public.best_selling_products OWNER TO postgres;

--
-- Name: branches; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.branches (
    branch_id integer NOT NULL,
    branch_name character varying(50) NOT NULL,
    location character varying(150),
    warehouse_address character varying(200)
);


ALTER TABLE public.branches OWNER TO postgres;

--
-- Name: branch_inventory; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.branch_inventory AS
 SELECT br.branch_name,
    p.name AS product_name,
    a.quantity
   FROM ((public.accomodates a
     JOIN public.branches br ON ((a.branch_id = br.branch_id)))
     JOIN public.products p ON ((a.product_id = p.product_id)));


ALTER VIEW public.branch_inventory OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id integer NOT NULL,
    order_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(20),
    total_amount numeric(10,2),
    invoice_number character varying(30),
    invoice_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    customer_id integer NOT NULL,
    branch_id integer NOT NULL,
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY (ARRAY[('Pending'::character varying)::text, ('Confirmed'::character varying)::text, ('Delivered'::character varying)::text, ('Cancelled'::character varying)::text, ('Returned'::character varying)::text])))
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: branch_revenue; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.branch_revenue AS
 SELECT b.branch_name,
    sum(o.total_amount) AS total_revenue
   FROM (public.orders o
     JOIN public.branches b ON ((o.branch_id = b.branch_id)))
  GROUP BY b.branch_id, b.branch_name;


ALTER VIEW public.branch_revenue OWNER TO postgres;

--
-- Name: branches_branch_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.branches ALTER COLUMN branch_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.branches_branch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: brands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.brands (
    brand_id integer NOT NULL,
    brand_name character varying(50) NOT NULL
);


ALTER TABLE public.brands OWNER TO postgres;

--
-- Name: brands_brand_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.brands ALTER COLUMN brand_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.brands_brand_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: categories_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.categories ALTER COLUMN category_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.categories_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    phone character varying(50),
    email character varying(50),
    address character varying(150),
    customer_type character varying(50)
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customer_orders; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.customer_orders AS
 SELECT o.order_id,
    c.first_name,
    c.last_name,
    o.order_date,
    o.status,
    o.total_amount
   FROM (public.orders o
     JOIN public.customers c ON ((o.customer_id = c.customer_id)));


ALTER VIEW public.customer_orders OWNER TO postgres;

--
-- Name: customer_spending; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.customer_spending AS
 SELECT c.customer_id,
    c.first_name,
    c.last_name,
    sum(o.total_amount) AS total_spent
   FROM (public.customers c
     JOIN public.orders o ON ((c.customer_id = o.customer_id)))
  GROUP BY c.customer_id, c.first_name, c.last_name;


ALTER VIEW public.customer_spending OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.customers ALTER COLUMN customer_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.customers_customer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employee_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    "position" character varying(50),
    phone character varying(15),
    email character varying(50),
    salary bigint,
    branch_id integer NOT NULL
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: employee_branch; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.employee_branch AS
 SELECT e.employee_id,
    e.first_name,
    e.last_name,
    e."position",
    b.branch_name
   FROM (public.employees e
     JOIN public.branches b ON ((e.branch_id = b.branch_id)));


ALTER VIEW public.employee_branch OWNER TO postgres;

--
-- Name: employees_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.employees ALTER COLUMN employee_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.employees_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.expenses (
    expense_id integer NOT NULL,
    branch_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    expense_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    description character varying(100),
    CONSTRAINT expenses_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.expenses OWNER TO postgres;

--
-- Name: expenses_expense_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.expenses ALTER COLUMN expense_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.expenses_expense_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: low_stock_products; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.low_stock_products AS
 SELECT p.name AS product_name,
    a.quantity,
    b.branch_name
   FROM ((public.accomodates a
     JOIN public.products p ON ((a.product_id = p.product_id)))
     JOIN public.branches b ON ((a.branch_id = b.branch_id)))
  WHERE (a.quantity < 20);


ALTER VIEW public.low_stock_products OWNER TO postgres;

--
-- Name: order_details; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.order_details AS
 SELECT oi.order_id,
    p.name AS product_name,
    oi.quantity,
    oi.price,
    oi.discount,
    oi.sub_total
   FROM (public.order_items oi
     JOIN public.products p ON ((oi.product_id = p.product_id)));


ALTER VIEW public.order_details OWNER TO postgres;

--
-- Name: order_items_order_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.order_items ALTER COLUMN order_item_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.order_items_order_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    payment_id integer NOT NULL,
    order_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_method character varying(50) NOT NULL,
    transaction_id character varying(50),
    payment_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT payments_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: order_payment_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.order_payment_summary AS
 SELECT o.order_id,
    o.total_amount,
    sum(p.amount) AS total_paid
   FROM (public.orders o
     JOIN public.payments p ON ((o.order_id = p.order_id)))
  GROUP BY o.order_id, o.total_amount;


ALTER VIEW public.order_payment_summary OWNER TO postgres;

--
-- Name: orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.orders ALTER COLUMN order_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.orders_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: out_of_stock_products; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.out_of_stock_products AS
 SELECT p.name AS product_name,
    a.quantity,
    b.branch_name
   FROM ((public.accomodates a
     JOIN public.products p ON ((a.product_id = p.product_id)))
     JOIN public.branches b ON ((a.branch_id = b.branch_id)))
  WHERE (a.quantity = 0);


ALTER VIEW public.out_of_stock_products OWNER TO postgres;

--
-- Name: payments_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.payments ALTER COLUMN payment_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.payments_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: product_catalog; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.product_catalog AS
 SELECT p.product_id,
    p.name AS product_name,
    c.category_name,
    b.brand_name,
    p.price,
    p.gst
   FROM ((public.products p
     JOIN public.categories c ON ((p.category_id = c.category_id)))
     JOIN public.brands b ON ((p.brand_id = b.brand_id)));


ALTER VIEW public.product_catalog OWNER TO postgres;

--
-- Name: return_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.return_items (
    return_item_id integer NOT NULL,
    return_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    item_condition character varying(20),
    refund_amount numeric(10,2) NOT NULL,
    CONSTRAINT return_items_item_condition_check CHECK (((item_condition)::text = ANY (ARRAY[('Unused'::character varying)::text, ('Damaged'::character varying)::text, ('Opened'::character varying)::text]))),
    CONSTRAINT return_items_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT return_items_refund_amount_check CHECK ((refund_amount >= (0)::numeric))
);


ALTER TABLE public.return_items OWNER TO postgres;

--
-- Name: product_returns; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.product_returns AS
 SELECT p.name AS product_name,
    ri.quantity,
    ri.item_condition,
    ri.refund_amount
   FROM (public.return_items ri
     JOIN public.products p ON ((ri.product_id = p.product_id)));


ALTER VIEW public.product_returns OWNER TO postgres;

--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.products ALTER COLUMN product_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.products_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: purchase_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_items (
    p_item_id integer NOT NULL,
    po_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    cost_price numeric(10,2) NOT NULL,
    sub_total numeric(10,2) GENERATED ALWAYS AS (((quantity)::numeric * cost_price)),
    CONSTRAINT purchase_items_cost_price_check CHECK ((cost_price > (0)::numeric)),
    CONSTRAINT purchase_items_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.purchase_items OWNER TO postgres;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_orders (
    po_id integer NOT NULL,
    supplier_id integer NOT NULL,
    branch_id integer NOT NULL,
    order_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    expected_date timestamp without time zone,
    status character varying(20),
    CONSTRAINT purchase_orders_status_check CHECK (((status)::text = ANY (ARRAY[('Pending'::character varying)::text, ('Confirmed'::character varying)::text, ('Shipped'::character varying)::text, ('Delivered'::character varying)::text, ('Cancelled'::character varying)::text])))
);


ALTER TABLE public.purchase_orders OWNER TO postgres;

--
-- Name: purchase_details; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.purchase_details AS
 SELECT p.name AS product_name,
    pi.quantity,
    pi.cost_price,
    po.order_date
   FROM ((public.purchase_items pi
     JOIN public.purchase_orders po ON ((pi.po_id = po.po_id)))
     JOIN public.products p ON ((pi.product_id = p.product_id)));


ALTER VIEW public.purchase_details OWNER TO postgres;

--
-- Name: purchase_items_p_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.purchase_items ALTER COLUMN p_item_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.purchase_items_p_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    supplier_id integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    email character varying(50),
    phone character varying(50),
    address character varying(150),
    gst_number character varying(50)
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: purchase_order_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.purchase_order_summary AS
 SELECT po.po_id,
    s.first_name,
    s.last_name,
    po.order_date,
    po.status
   FROM (public.purchase_orders po
     JOIN public.suppliers s ON ((po.supplier_id = s.supplier_id)));


ALTER VIEW public.purchase_order_summary OWNER TO postgres;

--
-- Name: purchase_orders_po_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.purchase_orders ALTER COLUMN po_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.purchase_orders_po_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: purchase_payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_payments (
    payment_id integer NOT NULL,
    po_id integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_method character varying(50) NOT NULL,
    transaction_id character varying(100) NOT NULL,
    payment_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT purchase_payments_amount_check CHECK ((amount > (0)::numeric))
);


ALTER TABLE public.purchase_payments OWNER TO postgres;

--
-- Name: purchase_payments_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.purchase_payments ALTER COLUMN payment_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.purchase_payments_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: return_items_return_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.return_items ALTER COLUMN return_item_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.return_items_return_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: return_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.return_orders (
    return_id integer NOT NULL,
    order_id integer NOT NULL,
    return_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reason character varying(100)
);


ALTER TABLE public.return_orders OWNER TO postgres;

--
-- Name: return_orders_return_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.return_orders ALTER COLUMN return_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.return_orders_return_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: return_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.return_summary AS
 SELECT r.return_id,
    o.order_id,
    r.return_date,
    r.reason
   FROM (public.return_orders r
     JOIN public.orders o ON ((r.order_id = o.order_id)));


ALTER VIEW public.return_summary OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    role_id integer NOT NULL,
    role_name character varying(50) NOT NULL,
    permission_level integer
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.roles ALTER COLUMN role_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.roles_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stock_movements (
    movement_id integer NOT NULL,
    product_id integer NOT NULL,
    from_branch_id integer NOT NULL,
    to_branch_id integer NOT NULL,
    quantity integer NOT NULL,
    movement_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    reason character varying(100),
    CONSTRAINT stock_movements_check CHECK ((from_branch_id <> to_branch_id)),
    CONSTRAINT stock_movements_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.stock_movements OWNER TO postgres;

--
-- Name: stock_movements_movement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.stock_movements ALTER COLUMN movement_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.stock_movements_movement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: supplies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplies (
    supplier_id integer NOT NULL,
    product_id integer NOT NULL
);


ALTER TABLE public.supplies OWNER TO postgres;

--
-- Name: supplier_products; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.supplier_products AS
 SELECT s.supplier_id,
    s.first_name,
    s.last_name,
    p.name AS product_name
   FROM ((public.supplies sp
     JOIN public.suppliers s ON ((sp.supplier_id = s.supplier_id)))
     JOIN public.products p ON ((sp.product_id = p.product_id)));


ALTER VIEW public.supplier_products OWNER TO postgres;

--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.suppliers ALTER COLUMN supplier_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.suppliers_supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.units (
    unit_id integer NOT NULL,
    unit_name character varying(50) NOT NULL,
    symbol character varying(20)
);


ALTER TABLE public.units OWNER TO postgres;

--
-- Name: units_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.units ALTER COLUMN unit_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.units_unit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_sessions (
    session_id integer NOT NULL,
    user_id integer NOT NULL,
    login_time timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    logout_time timestamp without time zone,
    device_info character varying(100)
);


ALTER TABLE public.user_sessions OWNER TO postgres;

--
-- Name: user_sessions_session_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.user_sessions ALTER COLUMN session_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_sessions_session_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(50) NOT NULL,
    password_hash character varying(100) NOT NULL,
    role_id integer NOT NULL,
    branch_id integer
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN user_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: accomodates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accomodates (branch_id, product_id, quantity) FROM stdin;
\.
COPY public.accomodates (branch_id, product_id, quantity) FROM '$$PATH$$/5343.dat';

--
-- Data for Name: branches; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.branches (branch_id, branch_name, location, warehouse_address) FROM stdin;
\.
COPY public.branches (branch_id, branch_name, location, warehouse_address) FROM '$$PATH$$/5347.dat';

--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.brands (brand_id, brand_name) FROM stdin;
\.
COPY public.brands (brand_id, brand_name) FROM '$$PATH$$/5350.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (category_id, category_name, description) FROM stdin;
\.
COPY public.categories (category_id, category_name, description) FROM '$$PATH$$/5344.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, first_name, last_name, phone, email, address, customer_type) FROM stdin;
\.
COPY public.customers (customer_id, first_name, last_name, phone, email, address, customer_type) FROM '$$PATH$$/5353.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employee_id, first_name, last_name, "position", phone, email, salary, branch_id) FROM stdin;
\.
COPY public.employees (employee_id, first_name, last_name, "position", phone, email, salary, branch_id) FROM '$$PATH$$/5355.dat';

--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.expenses (expense_id, branch_id, amount, expense_date, description) FROM stdin;
\.
COPY public.expenses (expense_id, branch_id, amount, expense_date, description) FROM '$$PATH$$/5357.dat';

--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (order_item_id, order_id, product_id, quantity, price, discount) FROM stdin;
\.
COPY public.order_items (order_item_id, order_id, product_id, quantity, price, discount) FROM '$$PATH$$/5345.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, order_date, status, total_amount, invoice_number, invoice_date, customer_id, branch_id) FROM stdin;
\.
COPY public.orders (order_id, order_date, status, total_amount, invoice_number, invoice_date, customer_id, branch_id) FROM '$$PATH$$/5348.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (payment_id, order_id, amount, payment_method, transaction_id, payment_date) FROM stdin;
\.
COPY public.payments (payment_id, order_id, amount, payment_method, transaction_id, payment_date) FROM '$$PATH$$/5360.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (product_id, name, category_id, brand_id, unit_id, price, gst, cost_price, description) FROM stdin;
\.
COPY public.products (product_id, name, category_id, brand_id, unit_id, price, gst, cost_price, description) FROM '$$PATH$$/5346.dat';

--
-- Data for Name: purchase_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_items (p_item_id, po_id, product_id, quantity, cost_price) FROM stdin;
\.
COPY public.purchase_items (p_item_id, po_id, product_id, quantity, cost_price) FROM '$$PATH$$/5365.dat';

--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_orders (po_id, supplier_id, branch_id, order_date, expected_date, status) FROM stdin;
\.
COPY public.purchase_orders (po_id, supplier_id, branch_id, order_date, expected_date, status) FROM '$$PATH$$/5366.dat';

--
-- Data for Name: purchase_payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_payments (payment_id, po_id, amount, payment_method, transaction_id, payment_date) FROM stdin;
\.
COPY public.purchase_payments (payment_id, po_id, amount, payment_method, transaction_id, payment_date) FROM '$$PATH$$/5386.dat';

--
-- Data for Name: return_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.return_items (return_item_id, return_id, product_id, quantity, item_condition, refund_amount) FROM stdin;
\.
COPY public.return_items (return_item_id, return_id, product_id, quantity, item_condition, refund_amount) FROM '$$PATH$$/5363.dat';

--
-- Data for Name: return_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.return_orders (return_id, order_id, return_date, reason) FROM stdin;
\.
COPY public.return_orders (return_id, order_id, return_date, reason) FROM '$$PATH$$/5371.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (role_id, role_name, permission_level) FROM stdin;
\.
COPY public.roles (role_id, role_name, permission_level) FROM '$$PATH$$/5373.dat';

--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stock_movements (movement_id, product_id, from_branch_id, to_branch_id, quantity, movement_date, reason) FROM stdin;
\.
COPY public.stock_movements (movement_id, product_id, from_branch_id, to_branch_id, quantity, movement_date, reason) FROM '$$PATH$$/5375.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (supplier_id, first_name, last_name, email, phone, address, gst_number) FROM stdin;
\.
COPY public.suppliers (supplier_id, first_name, last_name, email, phone, address, gst_number) FROM '$$PATH$$/5368.dat';

--
-- Data for Name: supplies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplies (supplier_id, product_id) FROM stdin;
\.
COPY public.supplies (supplier_id, product_id) FROM '$$PATH$$/5377.dat';

--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.units (unit_id, unit_name, symbol) FROM stdin;
\.
COPY public.units (unit_id, unit_name, symbol) FROM '$$PATH$$/5379.dat';

--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_sessions (session_id, user_id, login_time, logout_time, device_info) FROM stdin;
\.
COPY public.user_sessions (session_id, user_id, login_time, logout_time, device_info) FROM '$$PATH$$/5381.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, username, email, password_hash, role_id, branch_id) FROM stdin;
\.
COPY public.users (user_id, username, email, password_hash, role_id, branch_id) FROM '$$PATH$$/5383.dat';

--
-- Name: branches_branch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.branches_branch_id_seq', 12, true);


--
-- Name: brands_brand_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.brands_brand_id_seq', 259, true);


--
-- Name: categories_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_category_id_seq', 30, true);


--
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 2000, true);


--
-- Name: employees_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_employee_id_seq', 480, true);


--
-- Name: expenses_expense_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.expenses_expense_id_seq', 5184, true);


--
-- Name: order_items_order_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_order_item_id_seq', 25022, true);


--
-- Name: orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_order_id_seq', 5000, true);


--
-- Name: payments_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_payment_id_seq', 9968, true);


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_product_id_seq', 6287, true);


--
-- Name: purchase_items_p_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchase_items_p_item_id_seq', 9000, true);


--
-- Name: purchase_orders_po_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchase_orders_po_id_seq', 3000, true);


--
-- Name: purchase_payments_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchase_payments_payment_id_seq', 2110, true);


--
-- Name: return_items_return_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.return_items_return_item_id_seq', 2000, true);


--
-- Name: return_orders_return_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.return_orders_return_id_seq', 150, true);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 6, true);


--
-- Name: stock_movements_movement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stock_movements_movement_id_seq', 11000, true);


--
-- Name: suppliers_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.suppliers_supplier_id_seq', 100, true);


--
-- Name: units_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.units_unit_id_seq', 10, true);


--
-- Name: user_sessions_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_sessions_session_id_seq', 2500, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 241, true);


--
-- Name: accomodates accomodates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accomodates
    ADD CONSTRAINT accomodates_pkey PRIMARY KEY (branch_id, product_id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (branch_id);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (brand_id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (category_id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (expense_id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (order_item_id);


--
-- Name: orders orders_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_invoice_number_key UNIQUE (invoice_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: purchase_items purchase_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_pkey PRIMARY KEY (p_item_id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (po_id);


--
-- Name: purchase_payments purchase_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_pkey PRIMARY KEY (payment_id);


--
-- Name: purchase_payments purchase_payments_transaction_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_transaction_id_key UNIQUE (transaction_id);


--
-- Name: return_items return_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_pkey PRIMARY KEY (return_item_id);


--
-- Name: return_orders return_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_orders
    ADD CONSTRAINT return_orders_pkey PRIMARY KEY (return_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (movement_id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplier_id);


--
-- Name: supplies supplies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplies
    ADD CONSTRAINT supplies_pkey PRIMARY KEY (supplier_id, product_id);


--
-- Name: order_items unique_order_product; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT unique_order_product UNIQUE (order_id, product_id);


--
-- Name: return_orders unique_order_return; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_orders
    ADD CONSTRAINT unique_order_return UNIQUE (order_id);


--
-- Name: purchase_items unique_purchase_product; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT unique_purchase_product UNIQUE (po_id, product_id);


--
-- Name: return_items unique_return_product; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT unique_return_product UNIQUE (return_id, product_id);


--
-- Name: payments unique_transaction_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT unique_transaction_id UNIQUE (transaction_id);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (unit_id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: accomodates accomodates_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accomodates
    ADD CONSTRAINT accomodates_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id);


--
-- Name: accomodates accomodates_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accomodates
    ADD CONSTRAINT accomodates_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: employees employees_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id);


--
-- Name: expenses expenses_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id);


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: orders orders_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id);


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


--
-- Name: payments payments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id) ON DELETE CASCADE;


--
-- Name: products products_brand_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES public.brands(brand_id);


--
-- Name: products products_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(category_id);


--
-- Name: products products_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.units(unit_id);


--
-- Name: purchase_items purchase_items_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_orders(po_id) ON DELETE CASCADE;


--
-- Name: purchase_items purchase_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_items
    ADD CONSTRAINT purchase_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: purchase_orders purchase_orders_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id);


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: purchase_payments purchase_payments_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_payments
    ADD CONSTRAINT purchase_payments_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_orders(po_id) ON DELETE CASCADE;


--
-- Name: return_items return_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: return_items return_items_return_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_items
    ADD CONSTRAINT return_items_return_id_fkey FOREIGN KEY (return_id) REFERENCES public.return_orders(return_id) ON DELETE CASCADE;


--
-- Name: return_orders return_orders_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.return_orders
    ADD CONSTRAINT return_orders_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id) ON DELETE CASCADE;


--
-- Name: stock_movements stock_movements_from_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_from_branch_id_fkey FOREIGN KEY (from_branch_id) REFERENCES public.branches(branch_id);


--
-- Name: stock_movements stock_movements_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: stock_movements stock_movements_to_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_to_branch_id_fkey FOREIGN KEY (to_branch_id) REFERENCES public.branches(branch_id);


--
-- Name: supplies supplies_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplies
    ADD CONSTRAINT supplies_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: supplies supplies_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplies
    ADD CONSTRAINT supplies_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id);


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: users users_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(branch_id);


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(role_id);


--
-- Name: accomodates; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.accomodates ENABLE ROW LEVEL SECURITY;

--
-- Name: accomodates admin_inventory_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_inventory_policy ON public.accomodates TO admin_role, inventory_staff_role USING (true);


--
-- Name: orders admin_orders_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_orders_policy ON public.orders TO admin_role USING (true);


--
-- Name: payments admin_payments_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_payments_policy ON public.payments TO admin_role USING (true);


--
-- Name: return_items admin_return_items_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_return_items_policy ON public.return_items TO admin_role USING (true);


--
-- Name: return_orders admin_return_orders_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_return_orders_policy ON public.return_orders TO admin_role USING (true);


--
-- Name: stock_movements admin_stock_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY admin_stock_policy ON public.stock_movements TO admin_role USING (true);


--
-- Name: accomodates branch_inventory_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY branch_inventory_policy ON public.accomodates TO manager_role, sales_exec_role, cashier_role, support_staff_role USING ((branch_id = ( SELECT users.branch_id
   FROM public.users
  WHERE ((users.username)::text = CURRENT_USER))));


--
-- Name: orders branch_orders_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY branch_orders_policy ON public.orders TO manager_role, sales_exec_role, cashier_role USING ((branch_id = ( SELECT users.branch_id
   FROM public.users
  WHERE ((users.username)::text = CURRENT_USER))));


--
-- Name: payments branch_payments_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY branch_payments_policy ON public.payments TO manager_role, cashier_role USING ((order_id IN ( SELECT o.order_id
   FROM public.orders o
  WHERE (o.branch_id = ( SELECT users.branch_id
           FROM public.users
          WHERE ((users.username)::text = CURRENT_USER))))));


--
-- Name: return_items branch_return_items_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY branch_return_items_policy ON public.return_items TO manager_role, cashier_role USING ((return_id IN ( SELECT ro.return_id
   FROM public.return_orders ro
  WHERE (ro.order_id IN ( SELECT o.order_id
           FROM public.orders o
          WHERE (o.branch_id = ( SELECT users.branch_id
                   FROM public.users
                  WHERE ((users.username)::text = CURRENT_USER))))))));


--
-- Name: return_orders branch_return_orders_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY branch_return_orders_policy ON public.return_orders TO manager_role, cashier_role USING ((order_id IN ( SELECT o.order_id
   FROM public.orders o
  WHERE (o.branch_id = ( SELECT users.branch_id
           FROM public.users
          WHERE ((users.username)::text = CURRENT_USER))))));


--
-- Name: stock_movements branch_stock_policy; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY branch_stock_policy ON public.stock_movements TO manager_role, inventory_staff_role USING (((from_branch_id = ( SELECT users.branch_id
   FROM public.users
  WHERE ((users.username)::text = CURRENT_USER))) OR (to_branch_id = ( SELECT users.branch_id
   FROM public.users
  WHERE ((users.username)::text = CURRENT_USER)))));


--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

--
-- Name: payments; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

--
-- Name: return_items; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.return_items ENABLE ROW LEVEL SECURITY;

--
-- Name: return_orders; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.return_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_movements; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;

--
-- Name: TABLE accomodates; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.accomodates TO admin_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.accomodates TO manager_role;
GRANT SELECT,INSERT,UPDATE ON TABLE public.accomodates TO inventory_staff_role;
GRANT SELECT ON TABLE public.accomodates TO support_staff_role;


--
-- Name: TABLE categories; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.categories TO admin_role;
GRANT SELECT ON TABLE public.categories TO support_staff_role;


--
-- Name: TABLE order_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.order_items TO admin_role;
GRANT SELECT ON TABLE public.order_items TO support_staff_role;


--
-- Name: TABLE products; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.products TO admin_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.products TO manager_role;
GRANT SELECT ON TABLE public.products TO sales_exec_role;
GRANT SELECT ON TABLE public.products TO inventory_staff_role;
GRANT SELECT ON TABLE public.products TO cashier_role;
GRANT SELECT ON TABLE public.products TO support_staff_role;


--
-- Name: TABLE best_selling_products; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.best_selling_products TO admin_role;
GRANT SELECT ON TABLE public.best_selling_products TO support_staff_role;


--
-- Name: TABLE branches; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.branches TO admin_role;
GRANT SELECT ON TABLE public.branches TO support_staff_role;


--
-- Name: TABLE branch_inventory; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.branch_inventory TO admin_role;
GRANT SELECT ON TABLE public.branch_inventory TO support_staff_role;


--
-- Name: TABLE orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.orders TO admin_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.orders TO manager_role;
GRANT SELECT,INSERT,UPDATE ON TABLE public.orders TO sales_exec_role;
GRANT SELECT,INSERT ON TABLE public.orders TO cashier_role;
GRANT SELECT ON TABLE public.orders TO support_staff_role;


--
-- Name: TABLE branch_revenue; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.branch_revenue TO admin_role;
GRANT SELECT ON TABLE public.branch_revenue TO support_staff_role;


--
-- Name: SEQUENCE branches_branch_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.branches_branch_id_seq TO admin_role;


--
-- Name: TABLE brands; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.brands TO admin_role;
GRANT SELECT ON TABLE public.brands TO support_staff_role;


--
-- Name: SEQUENCE brands_brand_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.brands_brand_id_seq TO admin_role;


--
-- Name: SEQUENCE categories_category_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.categories_category_id_seq TO admin_role;


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customers TO admin_role;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.customers TO manager_role;
GRANT SELECT,INSERT ON TABLE public.customers TO sales_exec_role;
GRANT SELECT ON TABLE public.customers TO cashier_role;
GRANT SELECT ON TABLE public.customers TO support_staff_role;


--
-- Name: TABLE customer_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customer_orders TO admin_role;
GRANT SELECT ON TABLE public.customer_orders TO support_staff_role;


--
-- Name: TABLE customer_spending; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.customer_spending TO admin_role;
GRANT SELECT ON TABLE public.customer_spending TO support_staff_role;


--
-- Name: SEQUENCE customers_customer_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.customers_customer_id_seq TO admin_role;


--
-- Name: TABLE employees; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.employees TO admin_role;
GRANT SELECT ON TABLE public.employees TO support_staff_role;


--
-- Name: TABLE employee_branch; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.employee_branch TO admin_role;
GRANT SELECT ON TABLE public.employee_branch TO support_staff_role;


--
-- Name: SEQUENCE employees_employee_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.employees_employee_id_seq TO admin_role;


--
-- Name: TABLE expenses; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.expenses TO admin_role;
GRANT SELECT ON TABLE public.expenses TO support_staff_role;


--
-- Name: SEQUENCE expenses_expense_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.expenses_expense_id_seq TO admin_role;


--
-- Name: TABLE low_stock_products; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.low_stock_products TO admin_role;
GRANT SELECT ON TABLE public.low_stock_products TO support_staff_role;


--
-- Name: TABLE order_details; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.order_details TO admin_role;
GRANT SELECT ON TABLE public.order_details TO support_staff_role;


--
-- Name: SEQUENCE order_items_order_item_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.order_items_order_item_id_seq TO admin_role;


--
-- Name: TABLE payments; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.payments TO admin_role;
GRANT INSERT ON TABLE public.payments TO cashier_role;
GRANT SELECT ON TABLE public.payments TO support_staff_role;


--
-- Name: TABLE order_payment_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.order_payment_summary TO admin_role;
GRANT SELECT ON TABLE public.order_payment_summary TO support_staff_role;


--
-- Name: SEQUENCE orders_order_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.orders_order_id_seq TO admin_role;


--
-- Name: TABLE out_of_stock_products; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.out_of_stock_products TO admin_role;
GRANT SELECT ON TABLE public.out_of_stock_products TO support_staff_role;


--
-- Name: SEQUENCE payments_payment_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.payments_payment_id_seq TO admin_role;


--
-- Name: TABLE product_catalog; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_catalog TO admin_role;
GRANT SELECT ON TABLE public.product_catalog TO support_staff_role;


--
-- Name: TABLE return_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.return_items TO admin_role;
GRANT SELECT ON TABLE public.return_items TO support_staff_role;
GRANT SELECT ON TABLE public.return_items TO manager_role;
GRANT SELECT ON TABLE public.return_items TO cashier_role;


--
-- Name: TABLE product_returns; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_returns TO admin_role;
GRANT SELECT ON TABLE public.product_returns TO support_staff_role;


--
-- Name: SEQUENCE products_product_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.products_product_id_seq TO admin_role;


--
-- Name: TABLE purchase_items; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.purchase_items TO admin_role;
GRANT SELECT ON TABLE public.purchase_items TO support_staff_role;


--
-- Name: TABLE purchase_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.purchase_orders TO admin_role;
GRANT SELECT ON TABLE public.purchase_orders TO support_staff_role;


--
-- Name: TABLE purchase_details; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.purchase_details TO admin_role;
GRANT SELECT ON TABLE public.purchase_details TO support_staff_role;


--
-- Name: SEQUENCE purchase_items_p_item_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.purchase_items_p_item_id_seq TO admin_role;


--
-- Name: TABLE suppliers; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.suppliers TO admin_role;
GRANT SELECT ON TABLE public.suppliers TO support_staff_role;


--
-- Name: TABLE purchase_order_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.purchase_order_summary TO admin_role;
GRANT SELECT ON TABLE public.purchase_order_summary TO support_staff_role;


--
-- Name: SEQUENCE purchase_orders_po_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.purchase_orders_po_id_seq TO admin_role;


--
-- Name: SEQUENCE return_items_return_item_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.return_items_return_item_id_seq TO admin_role;


--
-- Name: TABLE return_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.return_orders TO admin_role;
GRANT SELECT ON TABLE public.return_orders TO support_staff_role;
GRANT SELECT ON TABLE public.return_orders TO manager_role;
GRANT SELECT ON TABLE public.return_orders TO cashier_role;


--
-- Name: SEQUENCE return_orders_return_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.return_orders_return_id_seq TO admin_role;


--
-- Name: TABLE return_summary; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.return_summary TO admin_role;
GRANT SELECT ON TABLE public.return_summary TO support_staff_role;


--
-- Name: TABLE roles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.roles TO admin_role;
GRANT SELECT ON TABLE public.roles TO support_staff_role;


--
-- Name: SEQUENCE roles_role_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.roles_role_id_seq TO admin_role;


--
-- Name: TABLE stock_movements; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.stock_movements TO admin_role;
GRANT INSERT,UPDATE ON TABLE public.stock_movements TO inventory_staff_role;
GRANT SELECT ON TABLE public.stock_movements TO support_staff_role;


--
-- Name: SEQUENCE stock_movements_movement_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.stock_movements_movement_id_seq TO admin_role;


--
-- Name: TABLE supplies; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplies TO admin_role;
GRANT SELECT ON TABLE public.supplies TO support_staff_role;


--
-- Name: TABLE supplier_products; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.supplier_products TO admin_role;
GRANT SELECT ON TABLE public.supplier_products TO support_staff_role;


--
-- Name: SEQUENCE suppliers_supplier_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.suppliers_supplier_id_seq TO admin_role;


--
-- Name: TABLE units; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.units TO admin_role;
GRANT SELECT ON TABLE public.units TO support_staff_role;


--
-- Name: SEQUENCE units_unit_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.units_unit_id_seq TO admin_role;


--
-- Name: TABLE user_sessions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_sessions TO admin_role;
GRANT SELECT ON TABLE public.user_sessions TO support_staff_role;


--
-- Name: SEQUENCE user_sessions_session_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.user_sessions_session_id_seq TO admin_role;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users TO admin_role;
GRANT SELECT ON TABLE public.users TO support_staff_role;
GRANT SELECT ON TABLE public.users TO manager_role;
GRANT SELECT ON TABLE public.users TO sales_exec_role;
GRANT SELECT ON TABLE public.users TO inventory_staff_role;
GRANT SELECT ON TABLE public.users TO cashier_role;


--
-- Name: SEQUENCE users_user_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.users_user_id_seq TO admin_role;


--
-- PostgreSQL database dump complete
--

